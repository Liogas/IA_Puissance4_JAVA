package controller;

import view.*;

/**
 * Main
 */
public class Main {

    public static void main(String[] args) {

        /*Affichage v = new Affichage();
        ControllerJeu ctrl = new ControllerJeu(jeu, p1, p2, v);
        ctrl.lancerJeu();*/

        Fenetre f = new Fenetre();
        f.setVisible(true);
    }

}