package model;

public enum Couleur {
	ROUGE, JAUNE, BLANC, VERT;
}