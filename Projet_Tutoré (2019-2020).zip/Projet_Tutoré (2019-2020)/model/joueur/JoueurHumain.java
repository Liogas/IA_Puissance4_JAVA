package model.joueur;

import model.*;


public class JoueurHumain extends Joueur{

	public JoueurHumain(Couleur color){
		super(color);
	}
}